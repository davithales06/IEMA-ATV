# IEMA ATV

Aplicativo web (PWA) de atividades, avisos e entregas para as unidades do IEMA (Maranhão).
Um único arquivo `site/index.html` (HTML + JavaScript) com banco de dados no Supabase e hospedagem no Cloudflare Pages.

## Pastas
- `site/` — o que vai para o ar (index.html, sw.js, manifest, ícones, _headers).
- `banco-de-dados/` — SQL do Supabase (rodar no SQL Editor, na ordem dos números).
- `tutor-thales/` — notas da função do tutor (a chave de IA fica só no painel do Supabase).

## Como publicar
1. No Cloudflare Pages, conecte este repositório.
2. Build command: (deixe vazio). Output directory: `site`.
3. A cada `git push`, o site é atualizado sozinho.

## Segurança
- Nunca coloque senhas, chaves secretas ou CSV de alunos neste repositório.
- A chave `anon` do Supabase que aparece no `index.html` é pública por desenho; quem protege os dados são as regras (RLS) do banco.
- Chaves de IA e do push ficam em Supabase > Edge Functions > Secrets.
