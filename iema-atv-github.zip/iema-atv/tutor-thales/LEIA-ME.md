A função `tutor` roda no Supabase (Edge Functions). O texto do guia do app fica dentro dela.
As chaves (GEMINI_API_KEY, GROQ_API_KEY ou ANTHROPIC_API_KEY) são cadastradas apenas em Supabase > Edge Functions > Secrets.
