-- IEMA ATV — rascunho do banco de dados (Supabase / PostgreSQL)
-- Ainda NÃO aplicado em nenhum projeto. Para revisão.

create table schools (
  id text primary key, name text not null unique,
  active boolean default true, bim int default 1, year int default extract(year from now())
);

create table profiles (
  id uuid primary key references auth.users on delete cascade,
  school_id text references schools,
  role text not null check (role in ('aluno','prof','aut','gestor','estadual')),
  name text not null, materia text,
  room_id uuid, is_leader boolean default false, graduated boolean default false,
  extra_points int default 0, created_at timestamptz default now()
);
-- dados sensíveis (LGPD) separados: só o próprio usuário e gestão da escola leem
create table profile_private (
  id uuid primary key references profiles on delete cascade,
  cpf text unique, birth_date date
);

create table rooms (id uuid primary key default gen_random_uuid(), school_id text references schools, name text not null);
alter table profiles add foreign key (room_id) references rooms;
create table prof_rooms (prof_id uuid references profiles, room_id uuid references rooms, primary key (prof_id, room_id));

create table posts (
  id uuid primary key default gen_random_uuid(), school_id text references schools,
  bim_key text not null, author_id uuid references profiles,
  cat text not null, title text not null, body text, due date,
  room_ids uuid[],                       -- null = todas as salas
  draft boolean default false, publish_at timestamptz,
  archived boolean default false, deleted boolean default false,
  created_at timestamptz default now()
);
create index on posts (school_id, bim_key, created_at desc);

create table submissions (
  id uuid primary key default gen_random_uuid(),
  post_id uuid references posts, student_id uuid references profiles, bim_key text not null,
  body text, status text default 'pendente' check (status in ('pendente','ok','inc')),
  late boolean default false, in_person boolean default false,
  receipt_no text unique, feedback text,
  reviewed_by uuid references profiles, reviewed_at timestamptz, created_at timestamptz default now()
);
create index on submissions (student_id, created_at);
create index on submissions (post_id);

-- anexos ficam no Storage (bucket "anexos"); aqui só o caminho
create table files (
  id uuid primary key default gen_random_uuid(),
  post_id uuid references posts, submission_id uuid references submissions,
  path text not null, name text, created_at timestamptz default now()
);

create table comments (id uuid primary key default gen_random_uuid(), post_id uuid references posts, author_id uuid references profiles, body text not null, created_at timestamptz default now());
create table messages (id uuid primary key default gen_random_uuid(), school_id text references schools, bim_key text, from_id uuid references profiles, to_id uuid references profiles, body text not null, read boolean default false, created_at timestamptz default now());
create table attendance (room_id uuid references rooms, day date, bim_key text, present uuid[], primary key (room_id, day));
create table events (id uuid primary key default gen_random_uuid(), school_id text references schools, day date, title text);

-- pontos: só entregas com visto contam (+15 antecedência, +10 no prazo, +3 atraso)
create view student_points as
select s.student_id,
  coalesce(sum(case when s.late then 3
                    when p.due is not null and s.created_at <= (p.due::timestamptz - interval '1 day') then 15
                    else 10 end),0) + max(pr.extra_points) as points
from submissions s join posts p on p.id = s.post_id join profiles pr on pr.id = s.student_id
where s.status = 'ok' group by s.student_id;

-- ===== segurança: cada escola só vê os próprios dados =====
create function my_school() returns text language sql stable security definer as $$ select school_id from profiles where id = auth.uid() $$;
create function my_role()   returns text language sql stable security definer as $$ select role      from profiles where id = auth.uid() $$;
create function my_room()   returns uuid language sql stable security definer as $$ select room_id   from profiles where id = auth.uid() $$;

alter table schools enable row level security;       create policy ver_escolas on schools for select using (true);
alter table profiles enable row level security;
create policy perfil_proprio  on profiles for select using (id = auth.uid());
create policy perfil_escola   on profiles for select using (school_id = my_school());   -- nomes dos colegas
alter table profile_private enable row level security;
create policy priv_proprio on profile_private for select using (id = auth.uid());
create policy priv_gestao  on profile_private for select using (my_role() in ('aut','gestor') and id in (select id from profiles where school_id = my_school()));
alter table rooms enable row level security;         create policy salas on rooms for select using (school_id = my_school());
alter table posts enable row level security;
create policy posts_ver on posts for select using (school_id = my_school() and not deleted and (my_role() <> 'aluno' or room_ids is null or my_room() = any(room_ids)));
create policy posts_criar on posts for insert with check (school_id = my_school() and author_id = auth.uid() and my_role() in ('prof','aut','gestor','aluno'));
create policy posts_editar on posts for update using (school_id = my_school() and (author_id = auth.uid() or my_role() in ('aut','gestor')));
alter table submissions enable row level security;
create policy sub_aluno on submissions for select using (student_id = auth.uid());
create policy sub_staff on submissions for select using (my_role() in ('prof','aut','gestor') and post_id in (select id from posts where school_id = my_school()));
create policy sub_enviar on submissions for insert with check (student_id = auth.uid() and status = 'pendente');
create policy sub_visto  on submissions for update using (my_role() in ('prof','aut','gestor') and post_id in (select id from posts where school_id = my_school()));
alter table messages enable row level security;
create policy msg on messages for select using (from_id = auth.uid() or to_id = auth.uid());
create policy msg_enviar on messages for insert with check (from_id = auth.uid() and school_id = my_school());
alter table comments enable row level security; alter table files enable row level security;
alter table attendance enable row level security; alter table events enable row level security;
