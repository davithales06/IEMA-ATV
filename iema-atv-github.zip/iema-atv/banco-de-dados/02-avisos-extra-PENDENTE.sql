-- IEMA ATV: avisos extras no celular (rodar uma vez no Supabase > SQL Editor)
-- 1) Nova entrega -> avisa o professor autor da atividade
create or replace function private.trg_subs_ins_push() returns trigger language plpgsql security definer set search_path to 'private','public' as $$
declare ttl text; au uuid; nm text;
begin
  if auth.uid() is distinct from NEW.student then return NEW; end if;
  select data->>'title', author into ttl, au from public.posts where id = NEW.post_id;
  select name into nm from public.profiles where id = NEW.student;
  if au is not null then
    perform private.push_notify(array[au], 'Nova entrega', coalesce(nm,'Aluno')||' · '||coalesce(ttl,''), '/', 'ent-'||NEW.post_id);
  end if;
  return NEW;
exception when others then return NEW;
end $$;
drop trigger if exists trg_subs_ins_push on public.subs;
create trigger trg_subs_ins_push after insert on public.subs for each row execute function private.trg_subs_ins_push();

-- 2) Calendario alterado -> avisa os alunos
create or replace function private.trg_events_upd_push() returns trigger language plpgsql security definer set search_path to 'private','public' as $$
declare ids uuid[]; k text := NEW.data->>'kind'; dt text;
begin
  if NEW.data->>'date' is null or NEW.data->>'date' !~ '^\d{4}-\d{2}-\d{2}$' then return NEW; end if;
  if k = 'prova-cancelada' then return NEW; end if;
  dt := to_char((NEW.data->>'date')::date,'DD/MM');
  select array_agg(pr.id) into ids from public.profiles pr
   where pr.school_id = NEW.school_id and pr.role = 'aluno'
     and (k is distinct from 'prova' or NEW.data->'rooms' is null or jsonb_exists(NEW.data->'rooms','all') or jsonb_exists(NEW.data->'rooms', coalesce(pr.room_id,'-')));
  perform private.push_notify(ids,
    case when k='prova' then 'Prova alterada: '||coalesce(NEW.data->>'prova','')||' — '||coalesce(NEW.data->>'materia','') when k='semaula' then 'Dia sem aula alterado' else 'Calendário alterado' end,
    case when k='semaula' then coalesce(NEW.data->>'title','')||' · '||dt else 'Agora no dia '||dt end,
    '/#cal', 'evu-'||NEW.id||'-'||dt);
  return NEW;
exception when others then return NEW;
end $$;
drop trigger if exists trg_events_upd_push on public.events;
create trigger trg_events_upd_push after update on public.events for each row
  when ((old.data->>'date') is distinct from (new.data->>'date') or (old.data->>'time') is distinct from (new.data->>'time') or (old.data->>'title') is distinct from (new.data->>'title') or (old.data->>'assuntos') is distinct from (new.data->>'assuntos'))
  execute function private.trg_events_upd_push();

-- 3) Lembrete das 18h (amanha): ignora dia de prova sem entrega e prazo estendido
create or replace function private.push_reminders() returns void language plpgsql security definer set search_path to 'private','public' as $$
declare r record; tm text := to_char((now() at time zone 'America/Fortaleza')::date + 1, 'YYYY-MM-DD'); e record; ids uuid[];
begin
  for r in
    select n, array_agg(uid) ids from (
      select pr.id uid, count(*) n from public.profiles pr
      join public.posts p on p.school_id = pr.school_id and (p.room_ids is null or pr.room_id = any(p.room_ids))
      where pr.role = 'aluno' and p.data->>'due' = tm
        and coalesce(p.data->>'cat','') in ('Atividade','Trabalho','Recuperação','AV1','AV2','AV3')
        and coalesce(p.data->>'noent','0') not in ('1','true')
        and coalesce(p.data->>'draft','0') not in ('1','true') and coalesce(p.data->>'del','0') not in ('1','true') and coalesce(p.data->>'arch','0') not in ('1','true')
        and not exists (select 1 from public.subs s where s.post_id = p.id and s.student = pr.id)
        and not exists (select 1 from public.ext x where x.post_id = p.id and x.student = pr.id and x.status = 'ok' and x.data->>'nd' > tm)
        and exists (select 1 from private.push_subs ps where ps.user_id = pr.id and not ps.dead)
      group by pr.id) x group by n
  loop
    perform private.push_notify(r.ids, 'Prazo amanhã', case when r.n = 1 then 'Você tem 1 atividade para entregar amanhã.' else 'Você tem '||r.n||' atividades para entregar amanhã.' end, '/', 'prazo-'||tm);
  end loop;
  for e in select * from public.events where data->>'kind' = 'prova' and data->>'date' = tm loop
    select array_agg(pr.id) into ids from public.profiles pr
     where pr.school_id = e.school_id and pr.role = 'aluno'
       and (e.data->'rooms' is null or jsonb_exists(e.data->'rooms','all') or jsonb_exists(e.data->'rooms', coalesce(pr.room_id,'-')));
    perform private.push_notify(ids, 'Prova amanhã: '||coalesce(e.data->>'prova',''), coalesce(e.data->>'materia','')||coalesce(' · '||nullif(e.data->>'time',''),''), '/#cal', 'prova-'||e.id);
  end loop;
end $$;

-- 4) Lembrete das 8h: prazo hoje / em 3 dias, provas hoje / 3 / 7 dias, prova-postagem sem entrega
create or replace function private.push_reminders_manha() returns void language plpgsql security definer set search_path to 'private','public' as $$
declare r record; e record; ids uuid[]; k int; d text; today date := (now() at time zone 'America/Fortaleza')::date; lbl text;
begin
  foreach k in array array[0,3] loop
    d := to_char(today + k, 'YYYY-MM-DD');
    for r in
      select n, array_agg(uid) ids from (
        select pr.id uid, count(*) n from public.profiles pr
        join public.posts p on p.school_id = pr.school_id and (p.room_ids is null or pr.room_id = any(p.room_ids))
        where pr.role = 'aluno' and p.data->>'due' = d
          and coalesce(p.data->>'cat','') in ('Atividade','Trabalho','Recuperação','AV1','AV2','AV3')
          and coalesce(p.data->>'noent','0') not in ('1','true')
          and coalesce(p.data->>'draft','0') not in ('1','true') and coalesce(p.data->>'del','0') not in ('1','true') and coalesce(p.data->>'arch','0') not in ('1','true')
          and not exists (select 1 from public.subs s where s.post_id = p.id and s.student = pr.id)
          and not exists (select 1 from public.ext x where x.post_id = p.id and x.student = pr.id and x.status = 'ok' and x.data->>'nd' > d)
          and exists (select 1 from private.push_subs ps where ps.user_id = pr.id and not ps.dead)
        group by pr.id) x group by n
    loop
      perform private.push_notify(r.ids, case when k = 0 then 'Prazo termina hoje' else 'Prazo em 3 dias' end,
        case when r.n = 1 then '1 atividade ainda não entregue.' else r.n||' atividades ainda não entregues.' end, '/', 'prazo8-'||k||'-'||d);
    end loop;
  end loop;
  foreach k in array array[0,3,7] loop
    d := to_char(today + k, 'YYYY-MM-DD');
    lbl := case when k = 0 then 'hoje' else 'em '||k||' dias' end;
    for e in select * from public.events where data->>'kind' = 'prova' and data->>'date' = d loop
      select array_agg(pr.id) into ids from public.profiles pr
       where pr.school_id = e.school_id and pr.role = 'aluno'
         and (e.data->'rooms' is null or jsonb_exists(e.data->'rooms','all') or jsonb_exists(e.data->'rooms', coalesce(pr.room_id,'-')));
      perform private.push_notify(ids, 'Prova '||lbl||': '||coalesce(e.data->>'prova',''), coalesce(e.data->>'materia','')||coalesce(' · '||nullif(e.data->>'time',''),''), '/#cal', 'prova8-'||k||'-'||e.id);
    end loop;
  end loop;
  foreach k in array array[0,1,3] loop
    d := to_char(today + k, 'YYYY-MM-DD');
    lbl := case when k = 0 then 'hoje' when k = 1 then 'amanhã' else 'em '||k||' dias' end;
    for e in select * from public.posts p where p.data->>'due' = d and coalesce(p.data->>'noent','0') in ('1','true')
        and coalesce(p.data->>'draft','0') not in ('1','true') and coalesce(p.data->>'del','0') not in ('1','true') and coalesce(p.data->>'arch','0') not in ('1','true') loop
      select array_agg(pr.id) into ids from public.profiles pr
       where pr.school_id = e.school_id and pr.role = 'aluno' and (e.room_ids is null or pr.room_id = any(e.room_ids));
      perform private.push_notify(ids, 'Prova '||lbl||': '||coalesce(e.data->>'title',''), 'Dia de prova. Não precisa entregar nada.', '/#cal', 'provap-'||k||'-'||e.id);
    end loop;
  end loop;
end $$;

select cron.schedule('push-lembretes-8h', '0 11 * * *', 'select private.push_reminders_manha()');
