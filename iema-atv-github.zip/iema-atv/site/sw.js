/* IEMA ATV — funcionamento sem internet */
const V='iema-atv-v16',B=self.registration.scope,IDX=B+'index.html',SHELL=[B,IDX,B+'manifest.webmanifest',B+'icon-192.png',B+'icon-512.png',B+'icon-maskable-192.png',B+'icon-maskable-512.png',B+'apple-touch-icon.png'];
const CDN=['https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.45.4/dist/umd/supabase.js'];
self.addEventListener('install',e=>{e.waitUntil((async()=>{const c=await caches.open(V);await Promise.all(SHELL.map(u=>c.add(u).catch(()=>{})));await Promise.all(CDN.map(u=>fetch(u,{mode:'no-cors'}).then(r=>c.put(u,r)).catch(()=>{})));self.skipWaiting()})())});
self.addEventListener('activate',e=>{e.waitUntil((async()=>{for(const k of await caches.keys())if(k!==V)await caches.delete(k);await self.clients.claim()})())});
self.addEventListener('fetch',e=>{const r=e.request;if(r.method!=='GET')return;const u=new URL(r.url);if(u.hostname.endsWith('supabase.co'))return;
 if(r.mode==='navigate'){e.respondWith(fetch(r).then(x=>{const k=x.clone();caches.open(V).then(c=>c.put(IDX,k));return x}).catch(()=>caches.match(IDX).then(x=>x||caches.match(B))));return}
 if(u.origin===location.origin){e.respondWith(fetch(r).then(x=>{if(x.ok){const k=x.clone();caches.open(V).then(c=>c.put(r,k))}return x}).catch(()=>caches.match(r)));return}
 if(/jsdelivr|unpkg/.test(u.hostname)){e.respondWith(caches.match(r).then(x=>x||fetch(r,{mode:'no-cors'}).then(y=>{const k=y.clone();caches.open(V).then(c=>c.put(r,k));return y})))}});

/* Notificações com o app fechado */
self.addEventListener('push',e=>{let d={};try{d=e.data?e.data.json():{}}catch(_){d={body:e.data?e.data.text():''}}
 e.waitUntil((async()=>{const cl=await self.clients.matchAll({type:'window',includeUncontrolled:true});
  if(d.tag!=='teste'&&cl.some(c=>c.visibilityState==='visible'&&c.focused))return;
  await self.registration.showNotification(d.title||'IEMA ATV',{body:d.body||'',icon:B+'icon-192.png',badge:B+'icon-192.png',tag:d.tag||undefined,renotify:!!d.tag,data:{url:d.url||B}})})())});
self.addEventListener('notificationclick',e=>{e.notification.close();const url=(e.notification.data&&e.notification.data.url)||B;
 e.waitUntil((async()=>{const cl=await self.clients.matchAll({type:'window',includeUncontrolled:true});for(const c of cl){if('focus' in c){await c.focus();c.postMessage({open:url});return}}await self.clients.openWindow(/^https?:/.test(url)?url:new URL(url=='/'?'./':url,B).href)})())});
